<?php
defined('BASEPATH') OR exit('No direct script access allowed');?>


<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default bg-lighterBlue fg-white">
            <div class="panel-body">
                <i class="fa fa-info-circle fa-lg"></i> Selamat datang <b>Admin</b>, Hari ini <?php echo tanggal_indo(date("Y-m-d G:i:s")); ?> anda login ke Website KadooKu.
            </div>
        </div>
    </div>

</div>